from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import numpy as np
import plotly.graph_objs as go
import plotly.offline as po

app = FastAPI()
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "plot_div": ""})

@app.post("/", response_class=HTMLResponse)
async def plot_function(request: Request, equation: str = Form(...)):
    try:
        x = np.linspace(-10, 10, 400)
        y = eval(equation, {"x": x, "np": np})
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", name=f"f(x) = {equation}"))
        fig.update_layout(title="Gráfico de la función", xaxis_title="x", yaxis_title="f(x)", template="plotly_white")
        plot_div = po.plot(fig, output_type="div", include_plotlyjs=False)
    except:
        plot_div = "<p style='color:red;'>Ecuación inválida. Ejemplos válidos: x**2 - 4, np.sin(x), np.exp(x) - 2</p>"

    return templates.TemplateResponse("index.html", {"request": request, "plot_div": plot_div})